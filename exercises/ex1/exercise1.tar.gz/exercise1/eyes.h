enum eye_colour {brown, green, blue};
void print(enum eye_colour x);
