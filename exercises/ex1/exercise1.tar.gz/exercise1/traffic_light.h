enum traffic_light {red, yellow, green};
void print(enum traffic_light x);
