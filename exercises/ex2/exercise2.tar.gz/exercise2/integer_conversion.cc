#include <iostream>
using std::cout;
using std::cin;
using std::endl;

int main()
{
    unsigned int x = 6;
    int y = 10;

    float a = x - y;
    int b = x - y;
    long c = x - y;

    cout << "a = " << a << '\n';
    cout << "b = " << b << '\n';
    cout << "c = " << c << '\n';

}
