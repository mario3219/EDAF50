#include "bitbuffer.h"

#include <iostream>

BitBuffer::BitBuffer(std::ostream& out) {}

void BitBuffer::put(bool b) {
}
