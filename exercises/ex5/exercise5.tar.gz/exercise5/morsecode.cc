#include "morsecode.h"

#include <fstream>
#include <sstream>

using std::string;

MorseCode::MorseCode() {
}

string MorseCode::encode(const string&) const {
	return "";
}

string MorseCode::decode(const string&) const {
	return "";
}
